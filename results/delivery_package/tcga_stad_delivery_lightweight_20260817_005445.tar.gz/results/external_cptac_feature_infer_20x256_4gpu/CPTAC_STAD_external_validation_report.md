# CPTAC-STAD External Validation Report

Date: 2026-08-09  
Feature set: `external_cptac_features_20x256`  
Inference output: `external_cptac_feature_infer_20x256_4gpu`

## 1. Data And Label Audit

This report evaluates the trained TCGA-STAD pathology models on the currently extracted CPTAC-STAD feature subset.

Input predictions:

- Patient predictions: `external_feature_patient_predictions.csv`
- Slide predictions: `external_feature_slide_predictions.csv`
- Inference errors: `external_feature_errors.json`

Labels were extracted from the 2026 CPTAC-STAD Cell Reports Medicine supplementary table:

- Raw supplemental file: `../../../../dataset/cptac-stad-histopathology/labels/cptac_stad_2026_supplement/1-s2.0-S2666379126001734-mmc2.xlsx`
- Derived QC-pass label file: `../../../../dataset/cptac-stad-histopathology/labels/cptac_stad_2026_tcga_subtype_labels_qc_pass.csv`

Label fields used:

- `Genomic_subtype`: TCGA four-class subtype, mapped as `EBV_Pos -> EBV`, `MSI_High -> MSI`, `GS -> GS`, `CIN -> CIN`
- `immune_sensitive`: `EBV` or `MSI` versus `GS` or `CIN`
- `msi`: MSI versus non-MSI
- `ebv`: EBV versus non-EBV

Coverage:

| Item | Count |
|---|---:|
| Inferred patients | 45 |
| Inferred slides | 174 |
| Inference errors | 0 |
| QC-pass labeled CPTAC-STAD patients | 157 |
| Evaluable patients with both prediction and QC-pass label | 42 |

Three inferred patients did not have QC-pass molecular labels and were excluded from supervised metrics:

```text
C3L-05521
C3L-06136
C3L-06767
```

Evaluable label distribution:

| Subtype | Patients |
|---|---:|
| EBV | 7 |
| MSI | 7 |
| GS | 13 |
| CIN | 15 |

## 2. Default Threshold Results

Default binary threshold: `0.5`.

| Task | n | Positive | AUC | AP | Accuracy | Balanced Accuracy | F1 | Precision | Recall | Specificity |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| EBV/MSI vs other | 42 | 14 | 0.883 | 0.850 | 0.905 | 0.911 | 0.867 | 0.812 | 0.929 | 0.893 |
| MSI | 42 | 7 | 0.800 | 0.592 | 0.786 | 0.814 | 0.571 | 0.429 | 0.857 | 0.771 |
| EBV | 42 | 7 | 0.988 | 0.957 | 0.881 | 0.643 | 0.444 | 1.000 | 0.286 | 1.000 |
| Four-class subtype | 42 | - | 0.766 macro OvR | - | 0.500 | - | 0.449 macro | - | - | - |

Default confusion matrices, rows are true labels and columns are predicted labels.

EBV/MSI vs other:

```text
[[25, 3],
 [ 1,13]]
```

MSI:

```text
[[27, 8],
 [ 1, 6]]
```

EBV:

```text
[[35, 0],
 [ 5, 2]]
```

Four-class subtype classes are `[EBV, MSI, GS, CIN]`:

```text
[[ 1, 3, 0, 3],
 [ 0, 5, 1, 1],
 [ 0, 2, 4, 7],
 [ 0, 0, 4,11]]
```

Interpretation:

- The combined EBV/MSI model transfers best among the evaluated tasks. It keeps high recall and specificity on CPTAC.
- MSI has useful ranking signal but has many false positives at threshold 0.5.
- EBV has very strong ranking signal, but threshold 0.5 is too strict for this external cohort. It detects only 2 of 7 EBV cases.
- Four-class subtype prediction is weaker, especially for EBV and GS. EBV is often assigned to MSI or CIN under the direct four-class head.

## 3. Threshold Tuning Results

Thresholds were selected on the current 42 labeled CPTAC patients. This is useful for calibration analysis, but it should be reported separately from the default-threshold external validation because it is optimized on the external set.

Thresholds maximizing balanced accuracy:

| Task | Tuned Threshold | Accuracy | Balanced Accuracy | F1 | Precision | Recall | Specificity | Confusion Matrix |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| EBV/MSI vs other | 0.494 | 0.905 | 0.911 | 0.867 | 0.812 | 0.929 | 0.893 | `[[25,3],[1,13]]` |
| MSI | 0.521 | 0.810 | 0.829 | 0.600 | 0.462 | 0.857 | 0.800 | `[[28,7],[1,6]]` |
| EBV | 0.088 | 0.929 | 0.957 | 0.824 | 0.700 | 1.000 | 0.914 | `[[32,3],[0,7]]` |

Alternative EBV threshold maximizing F1:

| Task | Threshold | Accuracy | Balanced Accuracy | F1 | Precision | Recall | Specificity | Confusion Matrix |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| EBV | 0.155 | 0.976 | 0.929 | 0.923 | 1.000 | 0.857 | 1.000 | `[[35,0],[1,6]]` |

For EBV, threshold tuning is critical. The ranking is excellent (`AUC=0.988`, `AP=0.957`), but the default threshold is under-sensitive on CPTAC. If the goal is screening, threshold `0.088` is preferable. If the goal is high-confidence EBV calls, threshold `0.155` is preferable.

## 4. Hierarchical Four-Class Rule

A thresholded hierarchical subtype rule was also tested:

```text
if ebv_prob >= 0.087825:
    predict EBV
elif msi_prob >= 0.520582:
    predict MSI
else:
    predict argmax(GS, CIN) using the M4 four-class head
```

This improved four-class performance:

| Method | Accuracy | Macro F1 |
|---|---:|---:|
| Direct M4 four-class head | 0.500 | 0.449 |
| Thresholded hierarchy | 0.571 | 0.580 |

Hierarchical confusion matrix, classes `[EBV, MSI, GS, CIN]`:

```text
[[7,0,0,0],
 [2,4,0,1],
 [0,3,4,6],
 [1,1,4,9]]
```

Per-class metrics for the hierarchical rule:

| Class | Support | Precision | Recall | F1 |
|---|---:|---:|---:|---:|
| EBV | 7 | 0.700 | 1.000 | 0.824 |
| MSI | 7 | 0.500 | 0.571 | 0.533 |
| GS | 13 | 0.500 | 0.308 | 0.381 |
| CIN | 15 | 0.562 | 0.600 | 0.581 |

## 5. Figures And Result Files

Main figures:

- Prediction probability histograms: [figures/fig1_probability_histograms.png](figures/fig1_probability_histograms.png)
- Patient prediction counts: [figures/fig2_patient_prediction_counts.png](figures/fig2_patient_prediction_counts.png)
- Patient probability heatmap: [figures/fig3_patient_probability_heatmap.png](figures/fig3_patient_probability_heatmap.png)
- Slide-patient consistency: [figures/fig4_slide_patient_consistency.png](figures/fig4_slide_patient_consistency.png)
- Coverage histograms: [figures/fig5_coverage_histograms.png](figures/fig5_coverage_histograms.png)
- Default-threshold ROC/PR: [figures/fig6_supervised_roc_pr_qc_labels.png](figures/fig6_supervised_roc_pr_qc_labels.png)
- Default-threshold confusion matrices: [figures/fig7_supervised_confusion_matrices_qc_labels.png](figures/fig7_supervised_confusion_matrices_qc_labels.png)
- Probability by label: [figures/fig8_supervised_probability_by_label_qc_labels.png](figures/fig8_supervised_probability_by_label_qc_labels.png)
- Threshold sweep curves: [figures/fig9_threshold_sweeps_qc_labels.png](figures/fig9_threshold_sweeps_qc_labels.png)
- Tuned-threshold confusion matrices: [figures/fig10_threshold_tuned_confusion_matrices_qc_labels.png](figures/fig10_threshold_tuned_confusion_matrices_qc_labels.png)

Main tables:

- Default supervised metrics: [figures/cptac_supervised_metrics_qc_labels.csv](figures/cptac_supervised_metrics_qc_labels.csv)
- Threshold tuned metrics: [figures/cptac_threshold_tuned_metrics_qc_labels.csv](figures/cptac_threshold_tuned_metrics_qc_labels.csv)
- Patient predictions with QC labels: [figures/cptac_patient_predictions_with_qc_labels.csv](figures/cptac_patient_predictions_with_qc_labels.csv)
- Patient predictions with tuned-threshold calls: [figures/cptac_patient_predictions_with_qc_labels_threshold_tuned.csv](figures/cptac_patient_predictions_with_qc_labels_threshold_tuned.csv)

## 6. Summary

On the currently extracted CPTAC-STAD feature subset, the TCGA-trained model shows meaningful external generalization for the clinically relevant EBV/MSI combined endpoint. The default EBV/MSI classifier achieved `AUC=0.883`, `balanced accuracy=0.911`, and `F1=0.867` on 42 labeled patients.

The individual EBV classifier has excellent ranking performance (`AUC=0.988`) but requires external calibration. With the default threshold 0.5, EBV recall is only `0.286`; after lowering the threshold to `0.088`, recall reaches `1.000` with specificity `0.914`. A more conservative F1-optimized EBV threshold `0.155` gives precision `1.000`, recall `0.857`, and F1 `0.923`.

MSI performance is moderate (`AUC=0.800`). The tuned threshold improves balanced accuracy slightly from `0.814` to `0.829`, but precision remains limited due to false positives.

Direct four-class subtype prediction is not robust enough as the primary endpoint in this subset (`accuracy=0.500`, `macro-F1=0.449`). A hierarchical strategy using tuned EBV/MSI binary heads before GS/CIN selection improves four-class performance to `accuracy=0.571`, `macro-F1=0.580`.

The present results should be treated as preliminary because only 42 labeled patients have completed feature extraction and matching. Final external validation should be rerun after feature extraction covers all QC-pass labeled CPTAC-STAD patients with available tumor WSIs.
